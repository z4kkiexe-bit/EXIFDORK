DOXXER - final files

frontend/src/...   -> copy into your frontend project's src folder (replace the old files)
frontend/.env.example -> copy to frontend/.env and fill in
backend/...        -> your backend folder (api.js replaces api.js AND server.js is no longer used)
                      run:  npm i express-rate-limit

Not included (unchanged, keep yours): main.jsx, index.css, index.html, package.json
Old preview page (doxxer-preview.html) is NOT part of the app.
